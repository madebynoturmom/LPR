import{d as s}from"../chunks/B96hbFDY.js";import{y as t}from"../chunks/DYNUYRjK.js";export{t as load_css,s as start};
