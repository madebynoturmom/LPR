import{d as s}from"../chunks/DNr0OUhH.js";import{y as t}from"../chunks/D27ElQeU.js";export{t as load_css,s as start};
