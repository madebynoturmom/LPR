import{a as r}from"../chunks/DioV78hU.js";import{y as t}from"../chunks/DC2F6t9P.js";export{t as load_css,r as start};
