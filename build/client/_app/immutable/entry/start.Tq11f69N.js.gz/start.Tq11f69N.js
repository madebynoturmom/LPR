import{d as s}from"../chunks/D9W8X6Gc.js";import{y as t}from"../chunks/AKi_3frM.js";export{t as load_css,s as start};
