import{d as s}from"../chunks/CK-fib3O.js";import{y as t}from"../chunks/tN8zdOQx.js";export{t as load_css,s as start};
