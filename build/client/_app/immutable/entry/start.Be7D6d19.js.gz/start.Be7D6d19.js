import{d as s}from"../chunks/0BRe-bZZ.js";import{y as t}from"../chunks/Cjiog9k2.js";export{t as load_css,s as start};
