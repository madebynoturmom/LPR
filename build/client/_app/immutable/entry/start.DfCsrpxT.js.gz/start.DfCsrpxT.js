import{d as s}from"../chunks/Bz7ZLckS.js";import{y as t}from"../chunks/ZMIOfXK-.js";export{t as load_css,s as start};
