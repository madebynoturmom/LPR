import{a as r}from"../chunks/CmBdg4qq.js";import{y as t}from"../chunks/CXo3jt2d.js";export{t as load_css,r as start};
