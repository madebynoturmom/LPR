import{d as s}from"../chunks/DC2OQAQI.js";import{y as t}from"../chunks/CoKub1NI.js";export{t as load_css,s as start};
