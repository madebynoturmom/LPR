import{d as s}from"../chunks/CrdiqAgI.js";import{y as t}from"../chunks/BvzuUZFe.js";export{t as load_css,s as start};
