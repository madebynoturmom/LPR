import{d as s}from"../chunks/WNbVgFxQ.js";import{y as t}from"../chunks/BSK96_y8.js";export{t as load_css,s as start};
