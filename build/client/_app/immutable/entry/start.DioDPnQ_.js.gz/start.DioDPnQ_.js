import{a as r}from"../chunks/DfxkLT-v.js";import{y as t}from"../chunks/BqEnfvlG.js";export{t as load_css,r as start};
