import{d as s}from"../chunks/DdKCIZXj.js";import{y as t}from"../chunks/EP93BFIp.js";export{t as load_css,s as start};
