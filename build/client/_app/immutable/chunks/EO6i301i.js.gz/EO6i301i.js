import{k as r,o as s}from"./MgvKJ5Oe.js";function d(i,t,n,a,l){r&&s();var e=t.$$slots?.[n],f=!1;e===!0&&(e=t.children,f=!0),e===void 0||e(i,f?()=>a:a)}export{d as s};
