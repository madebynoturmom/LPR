import{h as r,a as s}from"./VJxR2mP4.js";function o(i,a,n,t,l){r&&s();var e=a.$$slots?.[n],f=!1;e===!0&&(e=a.children,f=!0),e===void 0||e(i,f?()=>t:t)}export{o as s};
