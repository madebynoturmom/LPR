import{ax as a}from"./N5lxWZGS.js";a();
