import{ax as a}from"./MgvKJ5Oe.js";a();
