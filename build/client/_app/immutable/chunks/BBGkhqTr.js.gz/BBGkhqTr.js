import{i as t}from"./D6_VZFDO.js";function o(e,r){var a=e.$$events?.[r.type],l=t(a)?a.slice():a==null?[]:[a];for(var s of l)s.call(this,r)}export{o as b};
