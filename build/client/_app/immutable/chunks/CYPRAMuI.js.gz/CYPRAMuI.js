import{ax as a}from"./VJxR2mP4.js";a();
